package au.edu.sydney.comp5216.project.entity;

public class ChatInfo {
    public String avatarUrl;
    public String userId;
    public String lastMessage;
    public String time;
}
